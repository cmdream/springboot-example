package com.test.test;

public class SystemVal {
	public static String id = "tcpQueue";
	public static RouteModel routeModel;
	public static AMqServer aMqServer = new AMqServer();
	public static TimerServer timerServer = new TimerServer();
	public static String ip;
	public static Integer port;
}
